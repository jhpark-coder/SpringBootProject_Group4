package com.creatorworks.nexus.member.dto;

import java.io.Serializable;

import com.creatorworks.nexus.member.entity.Member;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SessionMemberFormDto implements Serializable{

    @NotBlank(message = "이름은 필수 입력 값입니다.")
    private String name;
    @NotEmpty(message = "성별은 필수 입력 값입니다.")
    private String gender;        // 성별 (male, female, other)
    @NotBlank(message = "생년은 필수 입력 값입니다.")
    private String birthYear;     // 생년
    @NotBlank(message = "생월은 필수 입력 값입니다.")
    private String birthMonth;    // 생월
    @NotBlank(message = "생일은 필수 입력 값입니다.")
    private String birthDay;      // 생일
    private String email;

    public SessionMemberFormDto() {

    }
    public SessionMemberFormDto(Member member) {
        this.name = member.getName();
        this.email = member.getEmail();
    }
}
