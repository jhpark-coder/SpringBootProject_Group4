package com.creatorworks.nexus.product.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductInquiryRequestDto {

    private String content;

    private Boolean isSecret;

} 