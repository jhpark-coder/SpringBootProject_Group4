package com.creatorworks.nexus.chat.entity;
 
public enum ChatMessageType {
    CHAT,   // 일반 채팅 메시지
    JOIN    // 사용자 입장 메시지
} 