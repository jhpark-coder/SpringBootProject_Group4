package com.creatorworks.nexus.order.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.creatorworks.nexus.member.entity.Member;
import com.creatorworks.nexus.member.repository.MemberRepository;
import com.creatorworks.nexus.notification.dto.PaymentNotificationRequest;
import com.creatorworks.nexus.notification.entity.NotificationCategory;
import com.creatorworks.nexus.notification.service.NotificationService;
import com.creatorworks.nexus.order.entity.Order;
import com.creatorworks.nexus.order.entity.Order.OrderStatus;
import com.creatorworks.nexus.order.entity.Order.OrderType;
import com.creatorworks.nexus.order.entity.OrderItem;
import com.creatorworks.nexus.order.entity.OrderItem.ItemType;
import com.creatorworks.nexus.order.entity.Payment;
import com.creatorworks.nexus.order.repository.OrderItemRepository;
import com.creatorworks.nexus.order.repository.OrderRepository;
import com.creatorworks.nexus.order.repository.PaymentRepository;
import com.creatorworks.nexus.product.entity.Product;
import com.creatorworks.nexus.product.repository.ProductRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Transactional
@RequiredArgsConstructor
public class PointService {

    private final MemberRepository memberRepository;
    private final ProductRepository productRepository;
    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final PaymentRepository paymentRepository;
    private final PaymentService paymentService;
    private final NotificationService notificationService;

    /**
     * 포인트 충전을 처리합니다.
     */
    public Order chargePoint(Long memberId, Long amount, String impUid, String merchantUid) {
        System.out.println("[LOG] chargePoint called: memberId=" + memberId + ", amount=" + amount + ", impUid=" + impUid + ", merchantUid=" + merchantUid); // TODO: 테스트 후 삭제
        try {
            Member member = memberRepository.findById(memberId)
                    .orElseThrow(() -> new IllegalArgumentException("회원을 찾을 수 없습니다: " + memberId));
            System.out.println("[LOG] member found: " + member.getEmail()); // TODO: 테스트 후 삭제

            // 중복 결제 방지
            if (impUid != null && paymentRepository.existsByImpUid(impUid)) {
                System.out.println("[LOG] 이미 처리된 결제: " + impUid); // TODO: 테스트 후 삭제
                throw new IllegalArgumentException("이미 처리된 결제입니다: " + impUid);
            }

            // 주문 생성
            Order order = Order.builder()
                    .buyer(member)
                    .orderType(OrderType.POINT_PURCHASE)
                    .orderStatus(OrderStatus.PENDING)
                    .totalAmount(amount)
                    .description("포인트 충전: " + amount + "원")
                    .build();

            order = orderRepository.save(order);
            System.out.println("[LOG] order saved: orderId=" + order.getId()); // TODO: 테스트 후 삭제

            // 주문 항목 생성
            OrderItem orderItem = OrderItem.builder()
                    .order(order)
                    .product(null) // 포인트 충전은 상품과 무관
                    .author(null)
                    .price(amount)
                    .quantity(1)
                    .itemType(ItemType.POINT_CHARGE)
                    .itemName("포인트 충전")
                    .description("포인트 " + amount + "원 충전")
                    .build();

            order.addOrderItem(orderItem);
            orderItemRepository.save(orderItem);
            System.out.println("[LOG] orderItem added"); // TODO: 테스트 후 삭제

            // 결제 정보 생성
            Payment payment = paymentService.processPointPayment(order, amount, merchantUid);
            order.setPayment(payment);
            System.out.println("[LOG] payment processed"); // TODO: 테스트 후 삭제

            return orderRepository.save(order);
        } catch (Exception e) {
            System.out.println("[ERROR] chargePoint 예외 발생: " + e.getMessage()); // TODO: 테스트 후 삭제
            e.printStackTrace(); // TODO: 테스트 후 삭제
            throw e;
        }
    }

    /**
     * 포인트로 상품을 구매합니다.
     */
    public Order purchaseWithPoint(Long memberId, Long productId, Integer quantity) {
        Member member = memberRepository.findById(memberId)
                .orElseThrow(() -> new IllegalArgumentException("회원을 찾을 수 없습니다: " + memberId));

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new IllegalArgumentException("상품을 찾을 수 없습니다: " + productId));

        Long totalAmount = product.getPrice() * quantity;

        // 포인트 잔액 확인
        Long currentBalance = getCurrentBalance(memberId);
        if (currentBalance < totalAmount) {
            throw new IllegalArgumentException("포인트가 부족합니다. 현재 잔액: " + currentBalance + "원, 필요 금액: " + totalAmount + "원");
        }

        // 주문 생성
        Order order = Order.builder()
                .buyer(member)
                .orderType(OrderType.PRODUCT_PURCHASE)
                .orderStatus(OrderStatus.PENDING)
                .totalAmount(totalAmount)
                .description("포인트로 상품 구매: " + product.getName())
                .build();

        order = orderRepository.save(order);

        // 주문 항목 생성
        OrderItem orderItem = OrderItem.builder()
                .order(order)
                .product(product)
                .author(product.getSeller())
                .price(product.getPrice())
                .quantity(quantity)
                .itemType(ItemType.PRODUCT)
                .itemName(product.getName())
                .description(product.getDescription())
                .build();

        order.addOrderItem(orderItem);
        orderItemRepository.save(orderItem);

        // 결제 정보 생성 (포인트 결제)
        String merchantUid = "point_" + System.currentTimeMillis();
        Payment payment = paymentService.processPointPayment(order, totalAmount, merchantUid);
        order.setPayment(payment);

        // 포인트 차감
        member.setPoint((int) (currentBalance - totalAmount));
        memberRepository.save(member);

        // 주문 완료 처리
        order.complete();
        payment.complete();

        return orderRepository.save(order);
    }

    /**
     * 현재 포인트 잔액을 조회합니다.
     */
    public Long getCurrentBalance(Long memberId) {
        Member member = memberRepository.findById(memberId)
                .orElseThrow(() -> new IllegalArgumentException("회원을 찾을 수 없습니다: " + memberId));
        
        return member.getPoint() != null ? member.getPoint().longValue() : 0L;
    }

    /**
     * 포인트 사용 내역을 조회합니다.
     */
    public Page<Order> getPointHistory(Long memberId, Pageable pageable) {
        Member member = memberRepository.findById(memberId)
                .orElseThrow(() -> new IllegalArgumentException("회원을 찾을 수 없습니다: " + memberId));

        return orderRepository.findByBuyerAndOrderTypeOrderByOrderDateDesc(member, OrderType.POINT_PURCHASE, pageable);
    }

    /**
     * 포인트를 추가합니다 (관리자용).
     */
    public Order addPoints(Long memberId, Long amount, String description) {
        Member member = memberRepository.findById(memberId)
                .orElseThrow(() -> new IllegalArgumentException("회원을 찾을 수 없습니다: " + memberId));

        Long currentBalance = getCurrentBalance(memberId);
        Long newBalance = currentBalance + amount;

        // 주문 생성 (관리자 지급)
        Order order = Order.builder()
                .buyer(member)
                .orderType(OrderType.POINT_PURCHASE)
                .orderStatus(OrderStatus.COMPLETED) // 관리자 지급은 바로 완료
                .totalAmount(amount)
                .description("관리자 지급: " + description)
                .build();

        order = orderRepository.save(order);

        // 주문 항목 생성
        OrderItem orderItem = OrderItem.builder()
                .order(order)
                .product(null)
                .author(null)
                .price(amount)
                .quantity(1)
                .itemType(ItemType.POINT_CHARGE)
                .itemName("관리자 포인트 지급")
                .description(description)
                .build();

        order.addOrderItem(orderItem);
        orderItemRepository.save(orderItem);

        // 결제 정보 생성 (관리자 지급)
        String merchantUid = "admin_" + System.currentTimeMillis();
        Payment payment = paymentService.processPointPayment(order, amount, merchantUid);
        payment.complete(); // 관리자 지급은 바로 완료
        order.setPayment(payment);

        // 포인트 추가
        member.setPoint(newBalance.intValue());
        memberRepository.save(member);

        return orderRepository.save(order);
    }

    /**
     * 포인트 충전 완료 처리 (적립 포인트 지정)
     */
    public void completePointCharge(String impUid, Long point) {
        Optional<Payment> paymentOpt = paymentService.findByImpUid(impUid);
        if (paymentOpt.isPresent()) {
            Payment payment = paymentOpt.get();
            Order order = payment.getOrder();
            if (order.getOrderType() == OrderType.POINT_PURCHASE) {
                // OrderItem이 없으면 생성
                if (order.getOrderItems() == null || order.getOrderItems().isEmpty()) {
                    OrderItem orderItem = OrderItem.builder()
                            .order(order)
                            .product(null)
                            .author(null)
                            .price(point)
                            .quantity(1)
                            .itemType(ItemType.POINT_CHARGE)
                            .itemName("포인트 충전")
                            .description("포인트 " + point + "원 충전")
                            .build();
                    
                    order.addOrderItem(orderItem);
                    orderItemRepository.save(orderItem);
                    log.info("포인트 충전 OrderItem 생성: orderId={}, itemId={}", order.getId(), orderItem.getId());
                }
                
                // 포인트 추가 (지정된 point 사용)
                Member member = order.getBuyer();
                Long currentBalance = getCurrentBalance(member.getId());
                Long newBalance = currentBalance + point;
                member.setPoint(newBalance.intValue());
                memberRepository.save(member);
                
                // 결제 완료 처리
                paymentService.completePayment(impUid);
                
                // 포인트 충전 성공 알림 전송
                sendPointChargeSuccessNotification(member, point, newBalance);
                
                log.info("포인트 충전 완료(지정): memberId={}, point={}, newBalance={}", member.getId(), point, newBalance);
            }
        }
    }

    /**
     * 포인트 충전 성공 알림 전송
     */
    private void sendPointChargeSuccessNotification(Member member, Long chargedAmount, Long newBalance) {
        try {
            String message = String.format("포인트가 성공적으로 충전되었습니다. 충전 금액: %,d원, 현재 잔액: %,d원", 
                chargedAmount, newBalance);
            
            PaymentNotificationRequest notificationDto = new PaymentNotificationRequest();
            notificationDto.setTargetUserId(member.getId());
            notificationDto.setMessage(message);
            notificationDto.setType("payment_success");
            notificationDto.setCategory(NotificationCategory.ADMIN);
            notificationDto.setLink("/User/my-page/points");
            notificationDto.setAmount(chargedAmount);
            notificationDto.setPaymentMethod("포인트 충전");
            notificationDto.setOrderId("point_" + System.currentTimeMillis());
            
            // 실시간 알림 전송
            notificationService.sendPaymentNotification(notificationDto);
            
            // DB에 알림 저장
            notificationService.savePaymentNotification(notificationDto, "/User/my-page/points");
            
            log.info("포인트 충전 성공 알림 전송 완료: userId={}, chargedAmount={}, newBalance={}", 
                member.getId(), chargedAmount, newBalance);
        } catch (Exception e) {
            log.error("포인트 충전 성공 알림 전송 실패: userId={}, error={}", member.getId(), e.getMessage());
        }
    }

    private void sendPointChargeFailureNotification(Member member, Long failedAmount, String reason) {
        try {
            String message = String.format("포인트 충전에 실패했습니다. 시도 금액: %,d원, 사유: %s", failedAmount, reason);
            
            PaymentNotificationRequest notificationDto = new PaymentNotificationRequest();
            notificationDto.setTargetUserId(member.getId());
            notificationDto.setMessage(message);
            notificationDto.setType("payment_failed");
            notificationDto.setCategory(NotificationCategory.ADMIN);
            notificationDto.setLink("/api/orders/points/charge-page"); // 실패시 charge-page로 이동
            notificationDto.setAmount(failedAmount);
            notificationDto.setPaymentMethod("포인트 충전");
            notificationDto.setOrderId("point_" + System.currentTimeMillis());
            
            // 실시간 알림 전송
            notificationService.sendPaymentNotification(notificationDto);
            
            // DB에 알림 저장
            notificationService.savePaymentNotification(notificationDto, "/api/orders/points/charge-page");
            
            log.info("포인트 충전 실패 알림 전송 완료: userId={}, failedAmount={}, reason={}", 
                member.getId(), failedAmount, reason);
        } catch (Exception e) {
            log.error("포인트 충전 실패 알림 전송 실패: userId={}, error={}", member.getId(), e.getMessage());
        }
    }

    public static class PointHistoryDto {
        public String description;
        public Long amount;
        public String type; // CHARGE/USE 등
        public java.time.LocalDateTime regTime;
        public Long balanceAfter;
    }

    public List<PointHistoryDto> getPointHistoryDtoList(Long memberId, Pageable pageable) {
        Page<Order> orders = getPointHistory(memberId, pageable);
        List<PointHistoryDto> result = new ArrayList<>();
        for (Order order : orders) {
            // 포인트 충전/사용 내역은 orderItems에서 첫 번째 아이템 기준으로 처리
            if (order.getOrderItems() != null && !order.getOrderItems().isEmpty()) {
                OrderItem item = order.getOrderItems().get(0);
                PointHistoryDto dto = new PointHistoryDto();
                dto.description = item.getDescription();
                dto.amount = item.getPrice();
                dto.type = item.getItemType() == ItemType.POINT_CHARGE ? "CHARGE" : "USE";
                dto.regTime = order.getOrderDate();
                dto.balanceAfter = null; // 필요시 계산 로직 추가
                result.add(dto);
            }
        }
        return result;
    }
} 