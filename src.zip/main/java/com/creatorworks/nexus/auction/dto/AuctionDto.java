package com.creatorworks.nexus.auction.dto;

public class AuctionDto {
}
