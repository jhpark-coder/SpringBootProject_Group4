package com.creatorworks.nexus.member.constant;

public enum Role {
    USER, ADMIN, SELLER
}
