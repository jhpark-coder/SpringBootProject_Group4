package com.creatorworks.nexus.member.repository;

public class EmailAuth {

}
