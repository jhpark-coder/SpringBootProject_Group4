package com.creatorworks.nexus.member.dto;

public class MemberDto {
}
