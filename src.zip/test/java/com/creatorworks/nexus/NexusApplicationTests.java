package com.creatorworks.nexus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NexusApplicationTests {

	@Test
	void contextLoads() {
	}

}
